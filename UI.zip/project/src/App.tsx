import { useState, useEffect } from 'react';
import { Leaf, Camera, Egg, Shield, Sparkles, TrendingUp, MapPin, ChevronRight } from 'lucide-react';

function App() {
  const [wasteCount, setWasteCount] = useState(1247);

  useEffect(() => {
    const interval = setInterval(() => {
      setWasteCount(prev => prev + Math.floor(Math.random() * 3));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-stone-50 to-amber-50">
      <Navbar />
      <HeroSection wasteCount={wasteCount} />
      <FeaturesGrid />
      <WasteMapPreview />
      <Footer />
    </div>
  );
}

function Navbar() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-2">
            <div className="relative">
              <Leaf className="w-8 h-8 text-emerald-600" strokeWidth={2.5} />
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-amber-500 rounded-full animate-pulse" />
            </div>
            <span className="text-xl font-bold text-stone-800">EcoCycle ID</span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            <a href="#beranda" className="text-stone-600 hover:text-emerald-600 transition-colors font-medium">Beranda</a>
            <a href="#mitra" className="text-stone-600 hover:text-emerald-600 transition-colors font-medium">Mitra</a>
            <a href="#peta" className="text-stone-600 hover:text-emerald-600 transition-colors font-medium">Peta Limbah</a>
            <a href="#login" className="text-stone-600 hover:text-emerald-600 transition-colors font-medium">Login</a>
          </div>

          <button className="bg-gradient-to-r from-emerald-600 to-emerald-700 text-white px-6 py-2.5 rounded-full font-semibold hover:shadow-lg hover:scale-105 transition-all duration-200">
            Gabung Sekarang
          </button>
        </div>
      </div>
    </nav>
  );
}

function HeroSection({ wasteCount }: { wasteCount: number }) {
  return (
    <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12 space-y-6">
          <div className="inline-flex items-center gap-2 bg-emerald-100 text-emerald-700 px-4 py-2 rounded-full text-sm font-semibold mb-4">
            <Sparkles className="w-4 h-4" />
            <span>ITB Hackathon 2025 Innovation</span>
          </div>

          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-stone-800 leading-tight">
            Ubah Limbah Makanan<br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-amber-600">
              Menjadi Cuan & Pakan
            </span>
          </h1>

          <p className="text-xl text-stone-600 max-w-3xl mx-auto leading-relaxed">
            Marketplace limbah organik pertama di Indonesia. Hubungkan dapur Anda dengan peternak lokal dalam satu klik.
          </p>

          <div className="flex items-center justify-center gap-2 text-stone-700 bg-white/60 backdrop-blur-sm px-6 py-3 rounded-full inline-flex border border-emerald-200">
            <TrendingUp className="w-5 h-5 text-emerald-600" />
            <span className="font-bold text-2xl text-emerald-600">{wasteCount.toLocaleString('id-ID')}</span>
            <span className="text-sm">Kg Limbah Terselamatkan Minggu Ini</span>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto mt-16">
          <ActionCard
            icon={<Camera className="w-10 h-10" />}
            title="Saya Punya Sampah"
            subtitle="Untuk Resto/Warga"
            description="Jual limbah organik Anda, dapatkan poin & uang"
            gradient="from-emerald-500 to-emerald-600"
            hoverGradient="from-emerald-600 to-emerald-700"
          />

          <ActionCard
            icon={<Egg className="w-10 h-10" />}
            title="Cari Pakan/Kompos"
            subtitle="Untuk Peternak"
            description="Akses pakan maggot & kompos berkualitas murah"
            gradient="from-amber-500 to-orange-600"
            hoverGradient="from-amber-600 to-orange-700"
          />
        </div>
      </div>
    </section>
  );
}

function ActionCard({ icon, title, subtitle, description, gradient, hoverGradient }: {
  icon: React.ReactNode;
  title: string;
  subtitle: string;
  description: string;
  gradient: string;
  hoverGradient: string;
}) {
  return (
    <button className={`group relative overflow-hidden bg-gradient-to-br ${gradient} hover:${hoverGradient} p-8 rounded-3xl text-white text-left transition-all duration-300 hover:scale-105 hover:shadow-2xl`}>
      <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-500" />

      <div className="relative z-10">
        <div className="bg-white/20 backdrop-blur-sm w-16 h-16 rounded-2xl flex items-center justify-center mb-4 group-hover:bg-white/30 transition-colors">
          {icon}
        </div>

        <h3 className="text-2xl font-bold mb-1">{title}</h3>
        <p className="text-white/80 text-sm font-medium mb-3">{subtitle}</p>
        <p className="text-white/90 text-base leading-relaxed">{description}</p>

        <div className="flex items-center gap-2 mt-6 text-sm font-semibold">
          <span>Mulai Sekarang</span>
          <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
        </div>
      </div>
    </button>
  );
}

function FeaturesGrid() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-stone-800 mb-4">
            Kenapa Pilih EcoCycle ID?
          </h2>
          <p className="text-xl text-stone-600">
            Teknologi terdepan untuk solusi limbah berkelanjutan
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <FeatureCard
            icon={<Sparkles className="w-8 h-8" />}
            title="AI Scan"
            description="Deteksi jenis sampah otomatis dengan AI. Cukup foto, sistem kami akan klasifikasi dan tentukan harga optimal."
            color="emerald"
          />

          <FeatureCard
            icon={<Shield className="w-8 h-8" />}
            title="Privacy First"
            description="Lokasi Anda disamarkan (Geohashing) untuk keamanan. Privasi adalah prioritas utama kami."
            color="blue"
          />

          <FeatureCard
            icon={<TrendingUp className="w-8 h-8" />}
            title="Cuan"
            description="Dapatkan poin atau uang dari sampah terpilah. Kontribusi kecil Anda bernilai ekonomi nyata."
            color="amber"
          />
        </div>
      </div>
    </section>
  );
}

function FeatureCard({ icon, title, description, color }: {
  icon: React.ReactNode;
  title: string;
  description: string;
  color: string;
}) {
  const colorMap: Record<string, { bg: string; icon: string; border: string }> = {
    emerald: { bg: 'bg-emerald-50', icon: 'text-emerald-600', border: 'border-emerald-200' },
    blue: { bg: 'bg-blue-50', icon: 'text-blue-600', border: 'border-blue-200' },
    amber: { bg: 'bg-amber-50', icon: 'text-amber-600', border: 'border-amber-200' }
  };

  const colors = colorMap[color];

  return (
    <div className={`${colors.bg} p-8 rounded-2xl border ${colors.border} hover:shadow-xl transition-all duration-300 hover:-translate-y-1`}>
      <div className={`${colors.icon} mb-4`}>
        {icon}
      </div>
      <h3 className="text-2xl font-bold text-stone-800 mb-3">{title}</h3>
      <p className="text-stone-600 leading-relaxed">{description}</p>
    </div>
  );
}

function WasteMapPreview() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-stone-50 to-emerald-50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl sm:text-5xl font-bold text-stone-800 mb-4">
            Peta Limbah Real-Time
          </h2>
          <p className="text-xl text-stone-600">
            Temukan atau posting limbah organik di sekitar Anda
          </p>
        </div>

        <div className="relative bg-white rounded-3xl p-8 shadow-2xl overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/10 to-amber-500/10" />

          <div className="relative aspect-video bg-stone-100 rounded-2xl overflow-hidden">
            <div className="absolute inset-0 flex items-center justify-center">
              <MapPin className="w-16 h-16 text-emerald-600 animate-bounce" />
            </div>

            <div className="absolute top-1/3 left-1/4 w-24 h-24 bg-emerald-500/30 rounded-full blur-2xl animate-pulse" />
            <div className="absolute top-1/2 right-1/3 w-32 h-32 bg-amber-500/30 rounded-full blur-2xl animate-pulse" style={{ animationDelay: '1s' }} />
            <div className="absolute bottom-1/3 left-1/2 w-20 h-20 bg-emerald-500/30 rounded-full blur-2xl animate-pulse" style={{ animationDelay: '2s' }} />

            <div className="absolute top-8 left-8 bg-white/95 backdrop-blur-md p-4 rounded-xl shadow-lg max-w-xs border border-emerald-200">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Leaf className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-stone-800 text-sm">Restoran Padang Sederhana</p>
                  <p className="text-xs text-stone-600 mt-1">Baru saja memposting <span className="font-bold text-emerald-600">5kg</span> nasi sisa</p>
                  <p className="text-xs text-stone-500 mt-1 flex items-center gap-1">
                    <MapPin className="w-3 h-3" />
                    Area Dago, Bandung
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8 text-center">
            <p className="text-stone-600 mb-4">
              Lokasi disamarkan untuk privasi. Kontak langsung setelah match.
            </p>
            <button className="bg-gradient-to-r from-emerald-600 to-emerald-700 text-white px-8 py-3 rounded-full font-semibold hover:shadow-lg hover:scale-105 transition-all duration-200 inline-flex items-center gap-2">
              <span>Lihat Peta Lengkap</span>
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-stone-800 text-stone-300 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
            <Leaf className="w-8 h-8 text-emerald-500" strokeWidth={2.5} />
            <span className="text-xl font-bold text-white">EcoCycle ID</span>
          </div>

          <div className="text-center md:text-right">
            <p className="text-sm">
              © 2025 EcoCycle ID - ITB Hackathon Team
            </p>
            <p className="text-xs text-stone-400 mt-1">
              Membangun masa depan berkelanjutan, satu limbah pada satu waktu
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default App;
